
import tkinter as tk
from tkinter import ttk
import sqlite3

class CustomMessageBox(tk.Toplevel):
    def __init__(self, parent, title="Message", message="This is a custom message", bg_color="#e0f7fa", fg_color="#00796b"):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=bg_color)
        self.geometry("300x150")
        
        message_label = tk.Label(self, text=message, font=("Arial", 12), bg=bg_color, fg=fg_color)
        message_label.pack(pady=20, padx=20)

        button_frame = tk.Frame(self, bg=bg_color)
        button_frame.pack(pady=10)

        ok_button = ttk.Button(button_frame, text="OK", command=self.on_ok)
        ok_button.pack(side="left", padx=5)
        
        cancel_button = ttk.Button(button_frame, text="Cancel", command=self.on_cancel)
        cancel_button.pack(side="left", padx=5)

    def on_ok(self):
        self.result = "ok"
        self.destroy()

    def on_cancel(self):
        self.result = "cancel"
        self.destroy()

class DistributorManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Coca-Cola Distributor Management System")
        self.root.geometry("900x600")
        self.root.configure(bg="#a7c7e7")

        self.products = ["Coca-Cola", "Maaza", "Sprite", "Fanta", "Limca", "Thums Up"]
        self.sizes = {"200ml": 20, "600ml": 40, "2 liters": 95, "Maaza Tetra Pack": 10}

        self.conn = sqlite3.connect("distributor_inventory.db")
        self.cursor = self.conn.cursor()
        self.create_table()

        self.create_widgets()
        self.populate_tree()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY,
                product TEXT,
                size TEXT,
                quantity INTEGER,
                price REAL
            )
        ''')
        self.conn.commit()

    def create_widgets(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        input_frame = ttk.LabelFrame(main_frame, text="Add Inventory Item", padding="10")
        input_frame.grid(column=0, row=0, padx=20, pady=20, sticky="ew")
        input_frame.configure(style="Custom.TLabelframe")

        ttk.Label(input_frame, text="Product:", style="Custom.TLabel").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.product_var = tk.StringVar()
        self.product_combo = ttk.Combobox(input_frame, textvariable=self.product_var, values=self.products, state="readonly", width=30)
        self.product_combo.grid(row=0, column=1, padx=5, pady=5)
        self.product_combo.current(0)

        ttk.Label(input_frame, text="Size:", style="Custom.TLabel").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.size_var = tk.StringVar()
        self.size_combo = ttk.Combobox(input_frame, textvariable=self.size_var, values=list(self.sizes.keys()), state="readonly", width=30)
        self.size_combo.grid(row=1, column=1, padx=5, pady=5)
        self.size_combo.current(0)

        ttk.Label(input_frame, text="Quantity:", style="Custom.TLabel").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.quantity_entry = ttk.Entry(input_frame, width=32)
        self.quantity_entry.grid(row=2, column=1, padx=5, pady=5)

        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=15)

        add_button = ttk.Button(button_frame, text="Add Item", command=self.add_item)
        add_button.pack(side=tk.LEFT, padx=5)

        delete_button = ttk.Button(button_frame, text="Delete Selected", command=self.delete_item)
        delete_button.pack(side=tk.LEFT, padx=5)

        list_frame = ttk.LabelFrame(main_frame, text="Inventory List", padding="10")
        list_frame.grid(column=0, row=1, padx=20, pady=10, sticky="nsew")
        list_frame.configure(style="Custom.TLabelframe")

        columns = ("Product", "Size", "Quantity", "Price")
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', selectmode="extended", height=15)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor=tk.CENTER, width=180)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        vertical_scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=vertical_scrollbar.set)
        vertical_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)

    def show_custom_message(self, title, message, bg_color="#e0f7fa", fg_color="#00796b"):
        msg_box = CustomMessageBox(self.root, title, message, bg_color, fg_color)
        self.root.wait_window(msg_box)
        return getattr(msg_box, 'result', None)

    def add_item(self):
        product = self.product_var.get()
        size = self.size_var.get()
        quantity_text = self.quantity_entry.get().strip()

        if not quantity_text.isdigit():
            self.show_custom_message("Invalid input", "Quantity should be a number.", bg_color="#ffcccc", fg_color="#cc0000")
            return
        quantity = int(quantity_text)

        price = self.sizes[size] * quantity
        self.cursor.execute("INSERT INTO inventory (product, size, quantity, price) VALUES (?, ?, ?, ?)", (product, size, quantity, price))
        self.conn.commit()

        self.populate_tree()
        self.clear_entries()
        self.show_custom_message("Success", "Item added successfully.")

    def clear_entries(self):
        self.product_combo.current(0)
        self.size_combo.current(0)
        self.quantity_entry.delete(0, tk.END)

    def populate_tree(self):
        self.tree.delete(*self.tree.get_children())
        self.cursor.execute("SELECT * FROM inventory")
        for row in self.cursor.fetchall():
            self.tree.insert("", tk.END, values=row[1:])

    def delete_item(self):
        selected_items = self.tree.selection()
        if not selected_items:
            self.show_custom_message("No selection", "Please select at least one item to delete.", bg_color="#ffcccc", fg_color="#cc0000")
            return

        confirm = self.show_custom_message("Confirm Deletion", "Are you sure you want to delete the selected item(s)?")
        if confirm == "ok":
            for item in selected_items:
                values = self.tree.item(item, "values")
                self.cursor.execute("DELETE FROM inventory WHERE product=? AND size=? AND quantity=? AND price=?", values)
                self.conn.commit()
                self.tree.delete(item)
            self.show_custom_message("Success", "Selected item(s) deleted successfully.")

    def __del__(self):
        self.conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    
    # Custom Styles
    style = ttk.Style(root)
    style.configure("Custom.TLabelframe", background="#a7c7e7", font=("Arial", 12))
    style.configure("Custom.TLabel", background="#a7c7e7", font=("Arial", 10, "bold"))

    app = DistributorManager(root)
    root.mainloop()
